Rhytm layout

compatable:   2.2.3
version:      1.0.0
vendor:       eSASe
vendor_email: alexermashev@gmail.com

Included layouts and templates for:

    module: Application
    version: 2.2.3
    vendor:  eSASe
    vendor email: alexermashev@gmail.com

    module: Page
    version: 2.2.3
    vendor:  eSASe
    vendor email: alexermashev@gmail.com

    module: Comment
    version: 1.0.0
    vendor:  eSASe
    vendor email: alexermashev@gmail.com

    module: News
    version: 1.0.4
    vendor:  eSASe
    vendor email: alexermashev@gmail.com
