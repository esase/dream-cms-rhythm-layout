<?php

return [
    'compatable' => '2.2.3',
    'version' => '1.0.0',
    'vendor' => 'eSASe',
    'vendor_email' => 'alexermashev@gmail.com'
];