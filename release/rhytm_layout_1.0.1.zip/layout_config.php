<?php 

return [
    'layout_name' => 'rhytm',
	'layout_path' => 'layout',
    'module_path' => [
        'Application' => 'module/application',
        'Page' => 'module/page',
        'News' => 'module/news'
    ]
];
