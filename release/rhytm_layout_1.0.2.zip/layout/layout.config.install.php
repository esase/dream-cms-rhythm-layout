<?php

return [
    'compatable' => '2.3.0',
    'version' => '1.0.2',
    'vendor' => 'eSASe',
    'vendor_email' => 'alexermashev@gmail.com'
];
