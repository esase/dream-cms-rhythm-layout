<?php

return [
    'compatable' => '2.2.4',
    'version' => '1.0.1',
    'vendor' => 'eSASe',
    'vendor_email' => 'alexermashev@gmail.com'
];
