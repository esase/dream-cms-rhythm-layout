<?php 

return [
    'layout_name' => 'rhytm',
    'compatable' => '2.2.4',
    'version' => '1.0.1',
    'vendor' => 'eSASe',
    'vendor_email' => 'alexermashev@gmail.com',
	'layout_path' => 'layout',
    'module_path' => [
        'Application' => 'module/application',
        'Page' => 'module/page'
    ]
];
