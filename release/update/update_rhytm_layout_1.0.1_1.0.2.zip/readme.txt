Rhytm layout update

compatable:   2.3.0
version:      1.0.2
vendor:       eSASe
vendor_email: alexermashev@gmail.com

Included layouts and templates for:

    module: Application
    version: 2.3.0
    vendor:  eSASe
    vendor email: alexermashev@gmail.com


    module: Page
    version: 2.3.0
    vendor:  eSASe
    vendor email: alexermashev@gmail.com
