<?php

return [
    'compatable' => '2.3.0',
    'version' => '1.0.3',
    'vendor' => 'eSASe',
    'vendor_email' => 'alexermashev@gmail.com'
];
