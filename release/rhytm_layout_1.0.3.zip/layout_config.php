<?php 

return [
    'layout_name' => 'rhythm',
	'layout_path' => 'layout',
	'module_path' => [
        'Application' => 'module/application',
        'Page' => 'module/page',
        'News' => 'module/news'
	]
];
